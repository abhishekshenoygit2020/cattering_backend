const pool = require("../../config/dbconfig");
const res = require("express/lib/response");
const { genSaltSync, hashSync} = require("bcrypt");

module.exports = {
    create:(data,callBack) => {
        pool.query(`select * from organisation where email = ?`,
            [data.email],
            (error,results) => {
                if(results == ""){
                    pool.query(
                        `INSERT INTO organisation(orgname, orgaddress, phone, email, contactname, logo) VALUES (?,?,?,?,?,?)`,
                        [
                            data.orgname,
                            data.orgaddress,
                            data.phone,
                            data.email,
                            data.contactname,
                            data.logo
                        ],
                        (error) => {
                            if(error){
                                return callBack(error);
                            }else{
                                var chars = "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                var passwordLength = 8;
                                var password = "";
                                for (var i = 0; i <= passwordLength; i++) {
                                    var randomNumber = Math.floor(Math.random() * chars.length);
                                    password += chars.substring(randomNumber, randomNumber +1);
                                   }
                                   var userRole = "admin";
                                   const salt = genSaltSync(10);
                                   var pwd = hashSync(password, salt);
                                pool.query(
                                    `INSERT INTO users(name,email,mobileno,password,userRole,companyCode) VALUES (?,?,?,?,?,?)`,
                                    [
                                        data.contactname,
                                        data.email,
                                        data.phone,
                                        pwd,
                                        userRole,
                                        data.orgname
                                    ],
                                    (error)=> {
                                        if(error){
                                            return callBack(error);
                                        }else{
                                            message = {
                                                email:data.email,
                                                password:password
                                            };
                                            return callBack(null,message);
                                        }
                                    }                                    
                                );
                                
                            }
                        }
                    );
                }else if(error){
                    return callBack(error);
                }else{
                    return callBack("Duplicate Entry found");
                }
            }
        );        
    },
    getStudentByID:(id, callBack) =>{
        pool.query(`select * from organisation where id = ?`,
            [id],
            (err,results) => {
                if(err){
                    return callBack(err);
                }else if(results == ""){                    
                    return callBack("Data not found");
                }else{  
                    return callBack(null, results);
                }
            }
        );
    },
    updatebyIds:(id,callBack) =>{
        pool.query(
            `update organisation set orgname=?, orgaddress=?, phone=?, email=?, contactname=?, logo=? where id = ?`,
            [ data.orgname,
                data.orgaddress,
                data.phone,
                data.email,
                data.contactname,
                data.logo,               
                id
            ],
            (error, results, fields) => {
                if(error){
                    console.log(error);
                }
                return callBack(null, results[0]);
            }
        );
   },
    getStudents:(callBack) =>{
        pool.query(`select * from organisation`,        
            (err,results) => {
                if(err){
                    return callBack(err);
                }else if(results == ""){                    
                    return callBack("Data not found");
                }else{  
                    return callBack(null, results);
                }
            }
        );
    },
    deleteByIds:(id,callBack) =>{
        pool.query(`delete from organisation where id=?`,
            [ 
                id
            ],        
            (err,results) => {
                if(err){
                    return callBack(err);
                }else if(results == ""){                    
                    return callBack("Data not found");
                }else{  
                    message = "Data deleted successfully";
                    return callBack(null, message);
                }
            }
    );
}
};